{backmatter}

# About the Author

Matt Cone is a technical writer at [Fastly](https://www.fastly.com). He has experience creating documentation for organizations like Linode and the U.S. Department of Health and Human Services. Matt's first book, *[Master Your Mac](https://www.amazon.com/Master-Your-Mac-Simple-Customize/dp/1593274068/)*, was published by No Starch Press. To get in touch with Matt, visit <https://www.mattcone.com>.
